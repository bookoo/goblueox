<?php
/**
 * The template for displaying the footer.
 *
 * Contains footer content and the closing of the
 * #main and #page div elements.
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?>


	 <!-- footer Start: -->
        <footer>
          <div class="footer">
          	<div class="top_footer">
              <div class="wrap">
                   <ul class="top_footer_menu">
                    <li class="footer_logo"><a href="<?php echo home_url('/'); ?>"><img src="<?php bloginfo('template_url')?>/images/footer_logo.png" alt=""></a></li>
                    
 <?php query_posts('category_name=our_mission&posts_per_page=');
				while (have_posts() ) : the_post(); ?>                    
                    
                    <li class="mission">
                    	<h6><?php the_title(); ?></h6>
                        <?php the_content(); ?>
                    </li>
 <?php endwhile;
	wp_reset_query(); ?>                   
                    
                    <li class="contact">
                    	<?php dynamic_sidebar('Blue_Ox : Contact_footer'); ?> 
                    </li>
                    <li class="sitemap">
                    	<h6>Sitemap</h6>
                    	<?php wp_nav_menu( array('menu' => 'footer_nav', 'menu_id' => '', 'menu_class' => '', 'container' => '' )); ?>
                    </li>
                   </ul>
                   <div class="top_footer_menu1">
                        <ul>
                        	<li class="footer_logo"><a href="<?php echo home_url('/'); ?>"><img src="<?php bloginfo('template_url'); ?>/images/footer_logo.png" alt=""></a></li>
<?php query_posts('category_name=our_mission&posts_per_page=');
				while (have_posts() ) : the_post(); ?>                    
                    
                    <li class="mission">
                    	<h6><?php the_title(); ?></h6>
                        <?php the_content(); ?>
                    </li>
 <?php endwhile;
	wp_reset_query(); ?> 
                        </ul>
                        <ul class="no_bg">
                        	<li class="contact">
                            	<?php dynamic_sidebar('Blue_Ox : Contact_footer'); ?>
                            </li>
                            <li class="sitemap">
                            	<h6>Sitemap</h6>
                                <?php wp_nav_menu( array('menu' => 'footer_nav', 'menu_id' => '', 'menu_class' => '', 'container' => '' )); ?>
                            </li>
                        </ul>
                        <div class="clear"></div>
                   </div>
                   <div class="clear"></div>
                   <?php dynamic_sidebar('Blue_Ox : Social_link'); ?> 
              </div>
            </div>
            <div class="clear"></div>
            <div class="bottom_footer">
            	<div class="wrap">
                	<?php dynamic_sidebar('Blue_Ox : Copyright'); ?>  
                </div>
            </div>   
         </div>   
        </footer>
        <!-- footer End: -->

</div>
<!-- End: Wrapper-->


<?php wp_footer(); ?>

</body>
</html>