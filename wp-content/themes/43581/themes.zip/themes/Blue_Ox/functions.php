<?php /**
 * Registers our main widget area and the front page widget areas.
 *
 * @since Twenty Twelve Child 1.0
 */
 
 
add_action( 'init', 'my_add_excerpts_to_pages' );

function my_add_excerpts_to_pages() {

add_post_type_support( 'page', 'excerpt' );
}




add_action('admin_menu','wphidenag');
function wphidenag() {
remove_action( 'admin_notices', 'update_nag', 3 );
}




//#######################################//
function remove_some_widgets(){
    unregister_sidebar( 'sidebar-1' );
    unregister_sidebar( 'sidebar-2' );
    unregister_sidebar( 'sidebar-3' );
}
add_action( 'widgets_init', 'remove_some_widgets', 11 );
//######################################//




if(!function_exists('Blue_Ox_widgets_init')) :

function Blue_Ox_widgets_init() {

	register_sidebar( array(
		'name' => __( 'Blue_Ox : comfort is a call away', 'Blue_Ox' ),
		'id' => 'sidebar-5',
		'description' => __( 'Appears on posts and pages except the optional Front Page template, which has its own widgets', 'Blue_Ox' ),
		'before_widget' => '',
		'after_widget' => '',
		'before_title' => '',
		'after_title' => '',
	) );

	register_sidebar( array(
		'name' => __( 'Blue_Ox : Contact_footer', 'Blue_Ox' ),
		'id' => 'sidebar-6',
		'description' => __( 'Appears when using the optional Front Page template with a page set as Static Front Page', 'Blue_Ox' ),
		'before_widget' => '',
		'after_widget' => '',
		'before_title' => '<h6>',
		'after_title' => '</h6>',
	) );

	register_sidebar( array(
		'name' => __( 'Blue_Ox : Social_link', 'Blue_Ox' ),
		'id' => 'sidebar-7',
		'description' => __( 'Appears when using the optional Front Page template with a page set as Static Front Page', 'Blue_Ox' ),
		'before_widget' => '',
		'after_widget' => '',
		'before_title' => '',
		'after_title' => '',
	) );
	
	register_sidebar( array(
		'name' => __( 'Blue_Ox : Copyright', 'Blue_Ox' ),
		'id' => 'sidebar-8',
		'description' => __( 'Appears when using the optional Front Page template with a page set as Static Front Page', 'Blue_Ox' ),
		'before_widget' => '',
		'after_widget' => '',
		'before_title' => '',
		'after_title' => '',
	) );

	register_sidebar( array(
		'name' => __( 'Blue_Ox : For when text', 'Blue_Ox' ),
		'id' => 'sidebar-9',
		'description' => __( 'Appears when using the optional Front Page template with a page set as Static Front Page', 'Blue_Ox' ),
		'before_widget' => '',
		'after_widget' => '',
		'before_title' => '',
		'after_title' => '',
	) );
	
	
}//
	
endif;//function exists	

add_action( 'widgets_init', 'Blue_Ox_widgets_init' );



?>