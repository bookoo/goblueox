<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package WordPress
 * @subpackage Twenty_Twelve
 * @since Twenty Twelve 1.0
 */
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<!-- <meta name="viewport" content="width=device-width" /> -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!--<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">-->
<!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->

<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />


<!-- Start: Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo dirname(get_bloginfo('stylesheet_url')); ?>/images/favicon.ico">
<!-- End: Favicon -->

<script src="<?php echo dirname(get_bloginfo('stylesheet_url')); ?>/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<script src="<?php echo dirname(get_bloginfo('stylesheet_url')); ?>/js/respond.min.js" type="text/javascript"></script>
<script src="<?php echo dirname(get_bloginfo('stylesheet_url')); ?>/js/css3-mediaqueries.js" type="text/javascript"></script>
<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>-->
<script type="text/javascript" src="<?php echo dirname(get_bloginfo('stylesheet_url')); ?>/js/jquery.cycle.all.js"></script>
<script type="text/javascript" src="<?php echo dirname(get_bloginfo('stylesheet_url')); ?>/js/jquery.responsive.cycle.slideshow.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	var slideshow = new SlideShow($('#slideshow'));
	$(window).bind('resize',function(){
	slideshow.update();
	});
	$(window).trigger('resize');
	});
</script>

<script type="text/javascript">
	$(document).ready(function(){
		$('a.nav_link').click(function(){
			$('.nav_phone ul.first,.iphone_header .nav_phone ul.first ').slideToggle();
		});
	});
</script>


<?php // Loads HTML5 JavaScript file to add support for HTML5 elements in older IE versions. ?>
<!--[if lt IE 9]>
<script src="<?php echo dirname(get_bloginfo('stylesheet_url')); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->
<?php wp_head(); ?>

<!-- Start: Stylesheet-->
<link href="<?php echo dirname(get_bloginfo('stylesheet_url')); ?>/css/responsive.css" rel="stylesheet" type="text/css">
<!-- End: Stylesheet-->


<!--[if lt IE 9]>
<style type="text/css">
	.first_container h1 { font-size:4.6em; padding-left:80px;}
	.first_container h5	{ padding-left:50px;}
	.second_conatiner h2 { line-height:68px;}
	.footer         { min-height:400px;}
ul.top_footer_menu li.footer_logo img	{ margin-left:0px;}
.second_conatiner h2	{ padding-left:60px;}
.second_conatiner h5	{ padding-left:50px;}
</style>
<![endif]-->

</head>

<body>


<!-- Start: Wrapper-->
<div class="wrapper">

        <!-- header Start: -->
        <header>
        	<div class="iphone_header">
            	<?php dynamic_sidebar('Blue_Ox : comfort is a call away'); ?>
                 <div class="nav_phone">
                                     <a href="#" class="nav_link">&nbsp;</a>
                                
                                 
                                 <?php wp_nav_menu( array('menu' => 'Header_nav', 'menu_id' => '', 'menu_class' => 'first', 'container' => '' )); ?> 
                  </div> 
            </div>
            <div class="header">
            <!-- Inner Header Start -->
              <div class="inner_header">
              	  <div class="wrap">
                            <div class="top_header">
                                <p>Comfort is a Call Away</p>
                                <?php dynamic_sidebar('Blue_Ox : comfort is a call away'); ?>
                            </div>
                            <div class="clear"></div>
                            <!-- Navigation Start -->
                            <section>
                              <div class="navigation">
                                <span class="logo"><a href="<?php echo home_url('/'); ?>"><img src="<?php echo dirname(get_bloginfo('stylesheet_url')); ?>/images/logo.png" alt=""></a></span>
                                <nav>
                                  <div class="nav">
                                   <?php wp_nav_menu( array('menu' => 'Header_nav', 'menu_id' => '', 'menu_class' => '', 'container' => '' )); ?> 
                                   </div>
                                  
                                   <div class="nav_phone" id="nav">
                                     <h6>Menu</h6>
                                     <a href="#" class="nav_link">&nbsp;</a>
                                    
                                        <?php wp_nav_menu( array('menu' => 'Header_nav', 'menu_id' => '', 'menu_class' => 'first', 'container' => '' )); ?>
                                   
                                  </div> 
                                </nav>
                               </div> 
                            </section>
                            <!-- Navigation End -->
                            <div class="clear"></div>
                            <!-- Banner Start -->
                            	<section>
                                	<div class="banner">
                                      <div id="slideshow">
                                      	<div class="cycle-slides">
                                        
<?php 
$i=0;
query_posts('category_name=banner_slider&posts_per_page=-1&order=ASC');
			while(have_posts()): the_post(); ?>                                      
                                        
                                                <div class="inner_banner">
                                                    <div class="left_banner">
                                                        <h1><?php the_title(); ?></h1>
                                                        <h2><?php $mykey_values = get_post_custom_values('Sub title'); print $mykey_values[0]; ?></h2>
                                                        <?php the_excerpt(); ?>
                                                        <span><a href="<?php the_permalink(); ?>">About Blue Ox</a></span>
                                                    </div>
                                                    <div class="right_banner">
                                                       <?php the_post_thumbnail('full'); ?>
                                                    </div>
                                                </div>
                                                
<?php
$i++;
endwhile;
	wp_reset_query(); ?> 
                                                
                                                
                                                
                                            </div>   
                                       </div> 
                                    </div>
                                </section>
                            <!-- Banner End -->
                      </div> 
              	 </div>
              <!-- Inner Header End -->
            </div>
        </header>
        <!-- header End: -->